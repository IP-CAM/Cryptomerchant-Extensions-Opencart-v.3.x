<?php

$_['text_title']      = 'Crypto Merchant';
$_['button_confirm']  = 'Pay with Crypto Merchant';
